--------------------------------------------------------
--  File created - Tuesday-January-22-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence ADDR_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ADDR_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 22001 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence APS_ALLOC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "APS_ALLOC_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 34965681 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence APS_PLAN_GRP_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "APS_PLAN_GRP_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence APS_RESULT_DTL_DMD_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "APS_RESULT_DTL_DMD_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 44649009 CACHE 1000 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence APS_SPLY_SUB_POOL_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "APS_SPLY_SUB_POOL_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 121 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence APS_SRC_RULE_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "APS_SRC_RULE_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 141 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence APS_SRC_RULE_SET_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "APS_SRC_RULE_SET_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 81 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence BIN_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "BIN_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 161 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence BOX_CD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "BOX_CD_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 317721 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence DEBUG_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "DEBUG_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 506043 CACHE 1000 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence FC_ADJ_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FC_ADJ_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 2383681 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence FC_AGGR_MAST_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FC_AGGR_MAST_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 124441 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence FC_ATTR_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FC_ATTR_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 35 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence FC_FCST_MDL_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FC_FCST_MDL_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 130 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence FC_FCST_NBR
--------------------------------------------------------

   CREATE SEQUENCE  "FC_FCST_NBR"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 11024354 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence FC_FCST_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FC_FCST_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 3782001 CACHE 1000 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence FC_FCST_NBR_SKIP_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FC_FCST_NBR_SKIP_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 100 START WITH 27354300 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence FC_FCST_PRD_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FC_FCST_PRD_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1324061 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence FC_HIST_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FC_HIST_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 3658801 CACHE 100 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence FC_ITEM_FCST_MDL_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FC_ITEM_FCST_MDL_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 6677364 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence FC_ITEM_MAST_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FC_ITEM_MAST_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 2127621 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence HUNDRED_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HUNDRED_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 100 START WITH 1500001 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IC_ATTR_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IC_ATTR_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 81 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IC_CATEGORY_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IC_CATEGORY_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 101 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IC_ITEM_LOC_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IC_ITEM_LOC_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 317721 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IC_ITEM_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IC_ITEM_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 10201 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IDL_AR_INV_DTL_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IDL_AR_INV_DTL_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IDL_CUST_MAST_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IDL_CUST_MAST_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IDL_IC_ITEM_ATTR_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IDL_IC_ITEM_ATTR_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 80401 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IDL_IC_ITEM_LOC_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IDL_IC_ITEM_LOC_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 66581 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IDL_IC_ITEM_MAST_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IDL_IC_ITEM_MAST_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 62961 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IDL_MFR_MFG_CAP_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IDL_MFR_MFG_CAP_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IDL_OE_ORD_DTL_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IDL_OE_ORD_DTL_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 9901 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence IDL_PO_ORD_DTL_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "IDL_PO_ORD_DTL_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 33181 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence ITEM_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ITEM_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 102940 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence LOT_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "LOT_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence OE_ORD_DTL_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OE_ORD_DTL_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 8253861 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence OE_ORD_HDR_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "OE_ORD_HDR_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 334321 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence ORG_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ORG_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 11121 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence PLAN_GRP_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PLAN_GRP_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 348381 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence PO_LINE_DTL_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PO_LINE_DTL_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 639761 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence PO_LINE_HDR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PO_LINE_HDR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 609541 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence PO_ORD_HDR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PO_ORD_HDR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 44761 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence TD_TASK_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TD_TASK_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence UT_SURROGATE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "UT_SURROGATE_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 25621 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence UT_USER_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "UT_USER_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 30 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence WANK_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "WANK_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 521 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
